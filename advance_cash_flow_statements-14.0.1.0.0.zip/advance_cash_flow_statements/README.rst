ADVANCED CASH FLOW STATEMENTS
=============================
Generate 4 levels of Dynamic Cash Flow Statements Report.

Configuration
=============

No additional configurations needed

Credits
=======
Developer: Varsha Vivek K @ cybrosys, Contact: odoo@cybrosys.com
          V14 Muhammed Nafih @cybrosys