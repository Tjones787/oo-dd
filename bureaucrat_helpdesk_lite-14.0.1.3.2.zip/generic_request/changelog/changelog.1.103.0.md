Added global configuration, that allows to chooses if it is needed to suggest
Global CC as recipients of request
