More information in error messages
