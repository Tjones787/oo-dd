- Added wsd public ui visibility to request's settings that allows to select whether to redirect unauthorized users to
login page or to show all request creation steps.
