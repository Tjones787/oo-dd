Merge with crnd_wsd_timesheet addon
