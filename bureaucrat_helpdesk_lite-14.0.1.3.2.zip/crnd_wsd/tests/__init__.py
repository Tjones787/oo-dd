from . import (
    test_tour,
    test_mail,
    test_upload_file,
)
