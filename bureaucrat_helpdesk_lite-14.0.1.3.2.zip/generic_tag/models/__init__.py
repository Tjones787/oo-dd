from . import (
    generic_tag_model,
    generic_tag_category,
    generic_tag,
)
