Added new mixin `generic.mixin.track.changes`
