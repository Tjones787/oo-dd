Now `tools.jinja.render_jinja_string` can receive custom jinja env.
