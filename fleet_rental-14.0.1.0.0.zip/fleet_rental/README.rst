Fleet Rental Management v14
===========================
This module will helps you to give the vehicles for Rent.


Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developers: 	Avinash NK @ cybrosys, odoo@cybrosys.com
                Version 14: Minhaj T @cybrosys


Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.
