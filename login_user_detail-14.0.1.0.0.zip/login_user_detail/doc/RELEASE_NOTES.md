## Module <login_user_detail>

#### 08.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial Commit for login_user_details