# -*- coding: utf-8 -*-

from . import hr_vacation
from . import hr_payslip
from . import hr_employee_ticket
