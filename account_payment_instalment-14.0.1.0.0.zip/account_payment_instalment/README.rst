Instalment in Payment Terms
===========================
This module will help you to manage the payment terms with instalments.

Features
========

* Instalment option in the payment term will helps to manage the payments of customer in instalments.

Installation
============
- www.odoo.com/documentation/14.0/setup/install.html
- Install our custom addon

License
-------
GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:  V12 Tintuk Tomin, odoo@cybrosys.com
              v13.0  Jibin James, odoo@cybrosys.com
              v14.0  Jibin James, odoo@cybrosys.com


Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__
